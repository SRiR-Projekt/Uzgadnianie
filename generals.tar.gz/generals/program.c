#include<stdio.h>
#include<mpi.h>
#include<stdlib.h>
#include<time.h>

#define STATE 4
#define TRAITOR_STATE 2

int main(int argc, char* argv[]) {
  int traitor, state, n, id;
  int traitor_tab[argc-1];
  double executionTime;

  if(argc < 2) {
    printf("Usage: ./program list_of_traitors.\n");
    exit(1);
  } else {
    for(int i=1; i<argc; i++) {
      traitor_tab[i-1] = atoi(argv[i]);
    }
    traitor = atoi(argv[1]);
  }

  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &id);
  MPI_Comm_size(MPI_COMM_WORLD, &n);

  int participStates[n], startStates[n];

  //=== GENERACJA LOSOWYCH STANOW OSZUSTOW ===

  if(id == 0) {
    srand(time(NULL));
    state = rand()%10;
    for(int i=0; i<n; i++) {
      startStates[i] = state;
      for(int j=0; j<argc-1; j++) {
        if(i == traitor_tab[j]) {
	  startStates[i] = rand()%10;
          break;
        }
      }
    }
  }
  MPI_Scatter(startStates, 1, MPI_INT, &state, 1, MPI_INT, 0, MPI_COMM_WORLD);

  executionTime = MPI_Wtime();

  //== KONIEC GENERACJI LOSOWYCH STANOW OSZUSTOW ===

  for(int i=0; i<n; i++) {
    startStates[i] = state;
  }

  MPI_Alltoall(startStates, 1, MPI_INT, participStates, 1, MPI_INT, MPI_COMM_WORLD);

  if(id == 0) {
    printf("Start states are: ");
    for(int i=0; i<n; i++) {
      printf("%d ", participStates[i]);
    }
  }

  int sum = 0;
  for(int i=0; i<n; i++) {
    sum += participStates[i];
  }

  if(sum == n*state) {
    if(id == 0) printf("%s", "Traitor not found!\n");
  } else {
    if(id == 0) printf("%s", "Traitor found!\n");
    int counts[n];

    //ZLICZENIA POSZCZEGOLNYCH STANOW
    for(int i=0; i<n; i++) {
      counts[i] = 0;
      for(int j=0; j<n; j++) {
        if(participStates[i] == participStates[j])
          counts[i]++;
      }
    }

    //POSZUKIWANIE MODY UKLADU
    int currentModeIndex = 0, currentMode = participStates[currentModeIndex];
    int badState = 0, differents = 0;
    for(int i=1; i<n; i++) {
      if(participStates[i] != currentMode) {
	differents = 1; //wystepuja rozne wartosci stanow w tablicy
	if(counts[i] > counts[currentModeIndex]) {
          currentModeIndex = i;
	  currentMode = participStates[currentModeIndex];
	}
      }
    }

    //SPRAWDZANIE CZY UKLAD JEST WIELOMODALNY
    if(differents) {
      for(int i=0; i<n; i++) {
        if(participStates[i] != currentMode && counts[i] == counts[currentModeIndex]) {
	  badState = 1; //WEJSCIE W TEN WARUNEK POWODUJE STAN NIEUSTALONY UKLADU
	  break;
        }
      }
    }

    if(!badState) { //STAN MOZLIWY DO USTALENIA
      for(int i=0; i<n; i++) {
	startStates[i] = currentMode;
      }

      MPI_Alltoall(startStates, 1, MPI_INT, participStates, 1, MPI_INT, MPI_COMM_WORLD);

      if(id == 0) {
        printf("%s", "States confirmed and sent\n");
        for(int i=0; i<n; i++) {
          printf("%d\n", participStates[i]);
        }
      }
    } else {
      printf("%s", "Unable to find common state.\n");
    }
  }

  executionTime = MPI_Wtime() - executionTime;
  if(id == 0) printf("Program execution time: %f.\n", executionTime);

  MPI_Finalize();

  return 0;
}
